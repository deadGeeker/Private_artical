Thanks
=====================

2010-07-04
---------------------

感谢 shiny(dev.meettea.com) 提供原创皮肤NoStyle

2010-04-26
---------------------

感谢 Michael·Q·Wang(qqworld.org) 为xhEditor设计了v1版Logo

Other
---------------------

开发过程中参考借鉴了以下产品，一并感谢：

1. CKEditor : http://ckeditor.com/
2. TinyMCE : http://tinymce.moxiecode.com/